<?php
class ControllerAccountOrder extends Controller {
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/order', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/order');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$url = '';

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_account'),
            'href' => $this->url->link('account/account', '', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('account/order', $url, true)
        );

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['orders'] = array();

		$this->load->model('account/order');


  		/* MP Seller Starts */
		$this->load->language('mpmultivendor/product');

		$data['column_seller_info'] = $this->language->get('column_seller_info');
		$data['column_product_name'] = $this->language->get('column_product_name');
		$data['column_store_name'] = $this->language->get('column_store_name');
		$data['column_mpseller_order_status'] = $this->language->get('column_mpseller_order_status');

		$this->load->model('account/mpmultivendor/orders');
		/* MP Seller Ends */
			
		$order_total = $this->model_account_order->getTotalOrders();

		$results = $this->model_account_order->getOrders(($page - 1) * 10, 10);

		foreach ($results as $result) {
			$product_total = $this->model_account_order->getTotalOrderProductsByOrderId($result['order_id']);
			$voucher_total = $this->model_account_order->getTotalOrderVouchersByOrderId($result['order_id']);


  		/* MP Seller Starts */
			$mpseller_order_products = $this->model_account_mpmultivendor_orders->getMpsellerOrderProducts($result['order_id']);

			// Seller Order Products Only
			$mpseller_order_products_data = array();
			foreach ($mpseller_order_products as $mpseller_order_product) {
				$all_seller_products = $this->model_account_mpmultivendor_orders->getAllMpsellerOrderProducts($result['order_id'], $mpseller_order_product['mpseller_id']);
				$all_seller_products_data = array();
				foreach ($all_seller_products as $all_seller_product) {
					$all_seller_products_data[] = $all_seller_product['name'];
				}

				$mpseller_info = $this->model_account_mpmultivendor_orders->getMpseller($mpseller_order_product['mpseller_id']);
				if($mpseller_info) {
					$mpseller_store_name = $mpseller_info['store_name'];
				} else {
					$mpseller_store_name = '';
				}

				$order_status_info = $this->model_account_mpmultivendor_orders->getOrderStatus($mpseller_order_product['order_status_id']);
				if($order_status_info) {
					$order_status_name = $order_status_info['name'];
				} else {
					$order_status_name = '';
				}

				$mpseller_order_products_data[] = array(
					'products' 		=> $all_seller_products_data,
					'mpseller_id' 	=> $mpseller_order_product['mpseller_id'],
					'store_name' 	=> $mpseller_store_name,
					'order_status' 	=> $order_status_name,
					'sold_by_type' 	=> 'seller',
					'order_id' 		=> $mpseller_order_product['order_id'],
				);
			}

			// Admin Order Products Only
			$admin_order_products = $this->model_account_mpmultivendor_orders->getAdminOrderProducts($result['order_id']);
			foreach ($admin_order_products as $admin_order_product) {
				$is_seller_products = $this->model_account_mpmultivendor_orders->getMpsellerOrderProduct($admin_order_product['order_id'], $admin_order_product['order_product_id']);
				if(!$is_seller_products) {
					$mpseller_store_name = $this->language->get('text_order_admin');
					$order_status_name 	 = $result['status'] ? $result['status'] : '';
					$mpseller_order_products_data[] = array(
						'products' 		=> array($admin_order_product['name']),
						'mpseller_id' 	=> '',
						'store_name' 	=> $mpseller_store_name,
						'order_status' 	=> $order_status_name,
						'sold_by_type' 	=> 'admin',
					);
				}
			}
			/* MP Seller Ends */
			
			$data['orders'][] = array(

	  			/* MP Seller Starts */
				'seller_products' => $mpseller_order_products_data,
				/* MP Seller Ends */
			
				'order_id'   => $result['order_id'],
				'name'       => $result['firstname'] . ' ' . $result['lastname'],
				'status'     => $result['status'],
				'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'products'   => ($product_total + $voucher_total),
				'total'      => $this->currency->format($result['total'], $result['currency_code'], $result['currency_value']),
				'view'       => $this->url->link('account/order/info', 'order_id=' . $result['order_id'], true),
			);
		}

		$pagination = new Pagination();
		$pagination->total = $order_total;
		$pagination->page = $page;
		$pagination->limit = 10;
		$pagination->url = $this->url->link('account/order', 'page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($order_total - 10)) ? $order_total : ((($page - 1) * 10) + 10), $order_total, ceil($order_total / 10));

		$data['continue'] = $this->url->link('account/account', '', true);

		$data['column_left'] = $this->load->controller('common/column_left');

                $data['content_full'] = $this->load->controller('common/content_full');
            
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$data['back_url'] = $this->url->link('account/account', '', true);

		$data['track_link'] = $this->url->link('account/order/track', '', true);


		$this->response->setOutput($this->load->view('account/order_list', $data));
	}

	public function info() {

        error_reporting(E_ALL);
        ini_set("display_errors", 1);

		$this->load->language('account/order');

        $this->document->addScript('catalog/view/javascript/mpseller/ratepicker/rate-picker.js');

		if (isset($this->request->get['order_id'])) {
			$order_id = $this->request->get['order_id'];
		} else {
			$order_id = 0;
		}

		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/order/info', 'order_id=' . $order_id, true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->model('account/order');

		$order_info = $this->model_account_order->getOrder($order_id);

		if ($order_info) {
			$this->document->setTitle($this->language->get('text_order'));

			$url = '';

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/home')
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_account'),
                'href' => $this->url->link('account/account', '', true)
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('account/order', $url, true)
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_order'),
                'href' => $this->url->link('account/order/info', 'order_id=' . $this->request->get['order_id'] . $url, true)
            );

			if (isset($this->session->data['error'])) {
				$data['error_warning'] = $this->session->data['error'];

				unset($this->session->data['error']);
			} else {
				$data['error_warning'] = '';
			}

			if (isset($this->session->data['success'])) {
				$data['success'] = $this->session->data['success'];

				unset($this->session->data['success']);
			} else {
				$data['success'] = '';
			}

			if ($order_info['invoice_no']) {
				$data['invoice_no'] = $order_info['invoice_prefix'] . $order_info['invoice_no'];
			} else {
				$data['invoice_no'] = '';
			}

			$data['order_id'] = $this->request->get['order_id'];
			$data['order_invoice'] = $order_info['invoice_prefix'].$order_info['invoice_no'];
			$data['date_added'] = date($this->language->get('date_format_short'), strtotime($order_info['date_added']));

			if ($order_info['payment_address_format']) {
				$format = $order_info['payment_address_format'];
			} else {
				$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			}

			$find = array(
				'{firstname}',
				'{lastname}',
				'{company}',
				'{address_1}',
				'{address_2}',
				'{city}',
				'{postcode}',
				'{zone}',
				'{zone_code}',
				'{country}'
			);

			$replace = array(
				'firstname' => $order_info['payment_firstname'],
				'lastname'  => $order_info['payment_lastname'],
				'company'   => $order_info['payment_company'],
				'address_1' => $order_info['payment_address_1'],
				'address_2' => $order_info['payment_address_2'],
				'city'      => $order_info['payment_city'],
				'postcode'  => $order_info['payment_postcode'],
				'zone'      => $order_info['payment_zone'],
				'zone_code' => $order_info['payment_zone_code'],
				'country'   => $order_info['payment_country']
			);

			$data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

			$data['payment_method'] = $order_info['payment_method'];

			if ($order_info['shipping_address_format']) {
				$format = $order_info['shipping_address_format'];
			} else {
				$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			}

			$find = array(
				'{firstname}',
				'{lastname}',
				'{company}',
				'{address_1}',
				'{address_2}',
				'{city}',
				'{postcode}',
				'{zone}',
				'{zone_code}',
				'{country}'
			);

			$replace = array(
				'firstname' => $order_info['shipping_firstname'],
				'lastname'  => $order_info['shipping_lastname'],
				'company'   => $order_info['shipping_company'],
				'address_1' => $order_info['shipping_address_1'],
				'address_2' => $order_info['shipping_address_2'],
				'city'      => $order_info['shipping_city'],
				'postcode'  => $order_info['shipping_postcode'],
				'zone'      => $order_info['shipping_zone'],
				'zone_code' => $order_info['shipping_zone_code'],
				'country'   => $order_info['shipping_country']
			);

			$data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

			$data['shipping_method'] = $order_info['shipping_method'];

			$this->load->model('catalog/product');
			$this->load->model('tool/upload');

			// Products
			$data['products'] = array();

			$products = $this->model_account_order->getOrderProducts($this->request->get['order_id']);

			foreach ($products as $product) {
				$option_data = array();

				$options = $this->model_account_order->getOrderOptions($this->request->get['order_id'], $product['order_product_id']);

				foreach ($options as $option) {
					if ($option['type'] != 'file') {
						$value = $option['value'];
					} else {
						$upload_info = $this->model_tool_upload->getUploadByCode($option['value']);

						if ($upload_info) {
							$value = $upload_info['name'];
						} else {
							$value = '';
						}
					}

					$option_data[] = array(
						'name'  => $option['name'],
						'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
					);
				}

				$product_info = $this->model_catalog_product->getProduct($product['product_id']);

				if ($product_info) {
					$reorder = $this->url->link('account/order/reorder', 'order_id=' . $order_id . '&order_product_id=' . $product['order_product_id'], true);
				} else {
					$reorder = '';
				}

				$data['products'][] = array(
					'product_id'=> $product['product_id'],
					'mpseller_id'=> $product['mpseller_id'],
					'store_name'=> $product['store_name'],
					'name'     => $product['name'],
					'model'    => $product['model'],
					'option'   => $option_data,
					'quantity' => $product['quantity'],
					'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
					'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']),
					'reorder'  => $reorder,
					'return'   => $this->url->link('account/return/add', 'order_id=' . $order_info['order_id'] . '&product_id=' . $product['product_id'], true),
                    'contact_seller'   => !empty($product['mpseller_id']) ? $this->url->link('mpmultivendor/store', 'mpseller_id=' . $product['mpseller_id'], true) : NULL,
                    'link'   => $this->url->link('product/product', 'product_id=' . $product['product_id'], true)
				);
			}

			// Voucher
			$data['vouchers'] = array();

			$vouchers = $this->model_account_order->getOrderVouchers($this->request->get['order_id']);

			foreach ($vouchers as $voucher) {
				$data['vouchers'][] = array(
					'description' => $voucher['description'],
					'amount'      => $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value'])
				);
			}

			// Totals
			$data['totals'] = array();

			$totals = $this->model_account_order->getOrderTotals($this->request->get['order_id']);

			foreach ($totals as $total) {
				$data['totals'][] = array(
					'title' => $total['title'],
					'text'  => $this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']),
				);
			}

			$data['comment'] = nl2br($order_info['comment']);
            $data['order_id'] = $order_id;
			// History
			$data['histories'] = array();

			$results = $this->model_account_order->getOrderHistories($this->request->get['order_id']);

	  		/* MP Seller Starts */
			$this->load->language('mpmultivendor/product');

			$data['column_postby'] = $this->language->get('column_postby');

			$this->load->model('account/mpmultivendor/orders');
			$results = $this->model_account_mpmultivendor_orders->getCustomerOrderHistories($this->request->get['order_id']);
			/* MP Seller Ends */
			

			foreach ($results as $result) {

  				/* MP Seller Starts */
				$mpseller_order_products_data = array();
				if($result['mpseller_id'] && $result['type'] == 'seller') {
					$mpseller_order_products = $this->model_account_mpmultivendor_orders->getOrderProducts($this->request->get['order_id'], $result['mpseller_id']);

					// Seller Order Products Only
					foreach ($mpseller_order_products as $mpseller_order_product) {
						$mpseller_order_products_data[] = $mpseller_order_product['name'];
					}
				} else {
					$mpseller_order_products_data[] = $this->language->get('text_all_products');
				}
				/* MP Seller Ends */
			
				$data['histories'][] = array(

	  				/* MP Seller Starts */
					'postby'     => $result['postby'],
					'order_id'   => $result['order_id'],
					'mpseller_id'=> $result['mpseller_id'],
					'type'     	 => $result['type'],
					'products'	 => $mpseller_order_products_data,
					/* MP Seller Ends */
			
					'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
					'status'     => $result['status'],
					'comment'    => $result['notify'] ? nl2br($result['comment']) : ''
				);
			}

			$data['continue'] = $this->url->link('account/order', '', true);

			$data['column_left'] = $this->load->controller('common/column_left');

                $data['content_full'] = $this->load->controller('common/content_full');
            
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');
            $data['back_url'] = $this->url->link('account/order ', '', true);

//            $this->load->model('mpmultivendor/mv_seller');
//            $data['sellers'] = $this->model_mpmultivendor_mv_seller->getSellersForEnquiry($this->customer->getId());

            //rating review
            $data['author'] = $this->customer->getFirstName() .' '. $this->customer->getLastName();

            $order_status_id = $this->model_account_order->getLatestOrderHistory($order_id, $this->customer->getId());
            $data['isVisibleCancelBtn'] =  false;

            if (in_array($order_status_id, array(1, 2,15))) {
                $data['isVisibleCancelBtn'] = true;
            }
            //echo '<pre>';print_r($data);exit('aaa');
			$this->response->setOutput($this->load->view('account/order_info', $data));
		} else {
			return new Action('error/not_found');
		}
	}

	public function reorder() {
		$this->load->language('account/order');

		if (isset($this->request->get['order_id'])) {
			$order_id = $this->request->get['order_id'];
		} else {
			$order_id = 0;
		}

		$this->load->model('account/order');

		$order_info = $this->model_account_order->getOrder($order_id);

		if ($order_info) {
			if (isset($this->request->get['order_product_id'])) {
				$order_product_id = $this->request->get['order_product_id'];
			} else {
				$order_product_id = 0;
			}

			$order_product_info = $this->model_account_order->getOrderProduct($order_id, $order_product_id);

			if ($order_product_info) {
				$this->load->model('catalog/product');

				$product_info = $this->model_catalog_product->getProduct($order_product_info['product_id']);

				if ($product_info) {
					$option_data = array();

					$order_options = $this->model_account_order->getOrderOptions($order_product_info['order_id'], $order_product_id);

					foreach ($order_options as $order_option) {
						if ($order_option['type'] == 'select' || $order_option['type'] == 'radio' || $order_option['type'] == 'image') {
							$option_data[$order_option['product_option_id']] = $order_option['product_option_value_id'];
						} elseif ($order_option['type'] == 'checkbox') {
							$option_data[$order_option['product_option_id']][] = $order_option['product_option_value_id'];
						} elseif ($order_option['type'] == 'text' || $order_option['type'] == 'textarea' || $order_option['type'] == 'date' || $order_option['type'] == 'datetime' || $order_option['type'] == 'time') {
							$option_data[$order_option['product_option_id']] = $order_option['value'];
						} elseif ($order_option['type'] == 'file') {
							$option_data[$order_option['product_option_id']] = $this->encryption->encrypt($this->config->get('config_encryption'), $order_option['value']);
						}
					}

					$this->cart->add($order_product_info['product_id'], $order_product_info['quantity'], $option_data);

					$this->session->data['success'] = sprintf($this->language->get('text_success'), $this->url->link('product/product', 'product_id=' . $product_info['product_id']), $product_info['name'], $this->url->link('checkout/cart'));

					unset($this->session->data['shipping_method']);
					unset($this->session->data['shipping_methods']);
					unset($this->session->data['payment_method']);
					unset($this->session->data['payment_methods']);
				} else {
					$this->session->data['error'] = sprintf($this->language->get('error_reorder'), $order_product_info['name']);
				}
			}
		}

		$this->response->redirect($this->url->link('account/order/info', 'order_id=' . $order_id));
	}

    public function track()
    {
	    $data = array();

        $data['column_left'] = $this->load->controller('common/column_left');

                $data['content_full'] = $this->load->controller('common/content_full');
            
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');


        //order tracking system
        $data['orders'] = array();
        $this->load->model('account/order');
        $orderId = !empty($this->request->get['order_id']) ? $this->request->get['order_id'] : '';
        $email = !empty($this->request->get['email']) ? $this->request->get['email'] : '';'';
        $order_invoice = !empty($this->request->get['invoice']) ? $this->request->get['invoice'] : '';
        $data['order_status'] = !empty($orderId) ? $this->model_account_order->getTrackTotalOrders($orderId, $email, $order_invoice) : '';
        $data['order_id'] = $orderId;
        $data['email'] = $email;
        $data['order_invoice'] = $order_invoice;
        $data['action'] = $this->url->link('account/order/track');
        $this->response->setOutput($this->load->view('account/order_track', $data));
    }

    public function cancel()
    {
        error_reporting(E_ALL);
        ini_set("display_errors", 1);

        if (!$this->customer->isLogged()) {
            $json['redirect'] = $this->url->link('account/login', '', true);
        }

        $json = array();

        $this->load->model('account/order');
        $this->load->model('account/customer');

        $this->load->language('account/order');

        if (empty($this->request->post['order_id'])) {
            $json['error'] = $this->language->get('error_order_id');
        }

        if (empty($this->request->post['selectReason'])) {
            $json['error'] = $this->language->get('error_selectReason');
        }

        if ((utf8_strlen(trim($this->request->post['inputReason'])) < 10) && $this->request->post['order_id'] == 7) {
            $json['error'] = $this->language->get('error_reason');
        }

        $order_id = $this->request->post['order_id'];
        if (!$json) {
            $cancel_data = array(
                'order_id' => $order_id,
                'customer_id' => $this->customer->getId(),
                'order_status_id' => 7,
                'notify' => 0,
                'comment' => $this->request->post['inputReason'],
                'cancel_reason_id' => $this->request->post['selectReason'],
            );
            $this->model_account_order->cancelOrder($cancel_data);

            if ($this->request->server['HTTPS']) {
                $server = $this->config->get('config_ssl');
            } else {
                $server = $this->config->get('config_url');
            }

            $customerData = $this->model_account_customer->getCustomer($this->customer->getId());
            $orderData = $this->model_account_order->getOrder($order_id);

            //Send mail to customer
            $data = [];
            $mail = new Mail($this->config->get('config_mail_engine'));
            $mail->parameter = $this->config->get('config_mail_parameter');
            $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
            $mail->smtp_username = $this->config->get('config_mail_smtp_username');
            $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
            $mail->smtp_port = $this->config->get('config_mail_smtp_port');
            $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
            $mail->setTo($customerData['email']);
            $mail->setFrom($this->config->get('config_email'));
            $mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
            $mail->setSubject(html_entity_decode(sprintf('The Champion Mall : Cancelled Order', $this->config->get('config_name'), $order_id), ENT_QUOTES, 'UTF-8'));
            $data['logo'] = $server . 'image/' . $this->config->get('config_logo');
            $data['store'] = html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
            $data['customer_name'] = $customerData['firstname'].' '.$customerData['lastname'];

            $mailText = $this->load->view('mail/order_cancel_to_customer', $data);
            $mail->setHtml($mailText);
            $mail->setText(html_entity_decode($mailText, ENT_QUOTES, 'UTF-8'));
            $mail->send();

            //Send mail to admin
            $dataAdmin = [];
            $mail = new Mail($this->config->get('config_mail_engine'));
            $mail->parameter = $this->config->get('config_mail_parameter');
            $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
            $mail->smtp_username = $this->config->get('config_mail_smtp_username');
            $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
            $mail->smtp_port = $this->config->get('config_mail_smtp_port');
            $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
            $mail->setTo($this->config->get('config_email'));
            $mail->setFrom($this->config->get('config_email'));
            $mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
            $mail->setSubject(html_entity_decode(sprintf('The Champion Mall : Cancelled Order By Customer', $this->config->get('config_name'), $order_id), ENT_QUOTES, 'UTF-8'));
            $dataAdmin['logo'] = $server . 'image/' . $this->config->get('config_logo');
            $dataAdmin['store'] = html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
            $dataAdmin['order_id'] =  '#' . $order_id;
            $dataAdmin['date_added'] = substr($orderData['date_added'], 0, 10);
            $dataAdmin['customer_name'] = $customerData['firstname'].' '.$customerData['lastname'];

            $mailText = $this->load->view('mail/order_cancel_to_admin', $dataAdmin);
            $mail->setHtml($mailText);
            $mail->setText(html_entity_decode($mailText, ENT_QUOTES, 'UTF-8'));
            $mail->send();

            //to send mail to multiple sellers (having that seller's products bought by customer)
            $sellers = $this->model_account_order->getMpsellerFromOrder($order_id);
            //print_r($sellers);exit('aaa');
            foreach ($sellers as $seller) {
                $dataSeller = [];
                $mail->setTo($seller['email']);
                $mail->setFrom($this->config->get('config_email'));
                $mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
                $mail->setSubject(html_entity_decode(sprintf('The Champion Mall : Cancelled Order', $this->config->get('config_name'), $order_id), ENT_QUOTES, 'UTF-8'));
                $dataSeller['logo'] = $server . 'image/' . $this->config->get('config_logo');
                $dataSeller['seller_name'] = $seller['store_owner'];
                $dataSeller['store_name'] = $seller['store_name'];
                $dataSeller['order_id'] =  '#' . $order_id;
                $dataSeller['customer_name'] = $customerData['firstname'].' '.$customerData['lastname'];
                $dataSeller['order_link'] = $this->url->link('account/mpmultivendor/orders/info', 'order_id=' . $order_id, true);
                $mailText = $this->load->view('mail/order_cancel_to_seller', $dataSeller);
                $mail->setHtml($mailText);
                $mail->setText(html_entity_decode($mailText, ENT_QUOTES, 'UTF-8'));
                $mail->send();
            }

            $json['success'] = $this->language->get('success_cancel_order');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function getSellerFromProduct()
    {
        $order_id = $this->request->get['order_id'];
    }
}